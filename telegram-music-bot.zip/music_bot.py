import os
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

TOKEN = os.getenv("BOT_TOKEN") or "ВСТАВ_СЮДИ_СВІЙ_ТОКЕН"

user_saved_tracks = {}

def search_music(query):
    url = f"https://itunes.apple.com/search"
    params = {"term": query, "media": "music", "limit": 5}
    response = requests.get(url, params=params)
    return response.json().get("results", [])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привіт! Надішли назву пісні — я знайду музику 🎶")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.message.text
    results = search_music(query)

    if not results:
        await update.message.reply_text("Нічого не знайдено 😢")
        return

    for track in results:
        title = track["trackName"]
        artist = track["artistName"]
        preview = track.get("previewUrl")

        keyboard = [[InlineKeyboardButton("💾 Зберегти", callback_data=f"save|{track['trackId']}")]]
        text = f"*{title}* — _{artist}_"

        if preview:
            await update.message.reply_audio(audio=preview, caption=text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            await update.message.reply_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))

        context.user_data[f"track_{track['trackId']}"] = track

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data
    if data.startswith("save|"):
        track_id = data.split("|")[1]
        user_id = query.from_user.id
        track = context.user_data.get(f"track_{track_id}")

        if track:
            user_saved_tracks.setdefault(user_id, []).append(track)
            await query.edit_message_reply_markup(reply_markup=None)
            await query.message.reply_text("✅ Трек збережено!")

async def saved(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    tracks = user_saved_tracks.get(user_id, [])

    if not tracks:
        await update.message.reply_text("У вас ще немає збережених треків.")
        return

    for track in tracks:
        title = track["trackName"]
        artist = track["artistName"]
        preview = track.get("previewUrl")
        text = f"*{title}* — _{artist}_"

        if preview:
            await update.message.reply_audio(audio=preview, caption=text, parse_mode="Markdown")
        else:
            await update.message.reply_text(text, parse_mode="Markdown")

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("saved", saved))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
app.add_handler(CallbackQueryHandler(button_handler))

app.run_polling()

#!/bin/bash
python3 music_bot.py
